i = 10

if (i > 15):
    print("10 is less than 15")
print("I am Not in if")