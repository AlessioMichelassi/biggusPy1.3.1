def printValues(values):
    for biggusNode in values:
        print(biggusNode)

numberNode = 6
values = [1, 2, 3, 4, 5]
printValues(values)