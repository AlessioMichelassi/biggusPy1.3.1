def add_and_multiply(a, b, c):
    d = a + b
    e = d * c
    return e


x = add_and_multiply(1, 2, 3)
y = add_and_multiply(4, 5, 6)
z = x + y
